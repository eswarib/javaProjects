public class Matrix {
    public static void main(String[] args)
    {

    }
}
