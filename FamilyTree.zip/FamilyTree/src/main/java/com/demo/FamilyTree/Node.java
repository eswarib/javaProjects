package com.demo.FamilyTree;

public class Node {
    public String name;
    public String gender;
    Node(String name,String gender){
        this.name = name;
        this.gender = gender;
    }
}
